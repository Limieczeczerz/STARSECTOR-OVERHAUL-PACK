package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Tags;

public class FighterHypoxia extends BaseHullMod {

	//public static float PD_DAMAGE_BONUS = 50f;
	//public static float SMOD_RANGE_BONUS = 100f;

	public static float MANEUVER_BONUS = 100f;

	public static float S_MOD_SPEED_BONUS = 50f;

	public static float ROAM_RANGE_PENALTY = 0.2f;
	

	@Override
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getFighterWingRange().modifyMult(id, ROAM_RANGE_PENALTY);
	}

	@Override
	public void applyEffectsToFighterSpawnedByShip(ShipAPI fighter, ShipAPI ship, String id) {
		//fighter.getMutableStats().getDamageToFighters().modifyFlat(id, PD_DAMAGE_BONUS / 100f);
		//fighter.getMutableStats().getDamageToMissiles().modifyFlat(id, PD_DAMAGE_BONUS / 100f);

		fighter.getMutableStats().getAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		fighter.getMutableStats().getDeceleration().modifyPercent(id, MANEUVER_BONUS);
		fighter.getMutableStats().getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		fighter.getMutableStats().getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS);
		
		boolean sMod = isSMod(ship);
		if (sMod) {
			fighter.getMutableStats().getMaxSpeed().modifyPercent(id, S_MOD_SPEED_BONUS);;
		}

		//if (fighter.getWing() != null && fighter.getWing().getSpec() != null) {
			//if (fighter.getWing().getSpec().isRegularFighter() ||
					//fighter.getWing().getSpec().isAssault() ||
					//fighter.getWing().getSpec().isBomber() ||
					//fighter.getWing().getSpec().isInterceptor()) {
				//fighter.addTag(Tags.WING_STAY_IN_FRONT_OF_SHIP);
			//}
		//}
	}
		
	public String getSModDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) S_MOD_SPEED_BONUS + "%";
		return null;
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) MANEUVER_BONUS + "%";
		if (index == 1) return "" + (int) (ROAM_RANGE_PENALTY*100) + "%";
		return null;
	}
	
	public boolean isApplicableToShip(ShipAPI ship) {
		int bays = (int) ship.getMutableStats().getNumFighterBays().getModifiedValue();
		return ship != null && bays > 0; 
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		return "Ship does not have fighter bays";
	}
}




