package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Horozit {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Horozit");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

		PlanetAPI star = system.initStar("horozit", "star_purple_giant", 1700, 2000, 20f, 2f, 8f);

		system.setLightColor(new Color(216, 191, 255)); // light color in entire system, affects all entities

		SectorEntityToken field3 = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(4000f, // terrain effect band width
						6000, // terrain effect middle radius
						star, // entity that it's around
						4000f, // visual band start
						8000f, // visual band end
						new Color(126, 151, 214, 40), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(158, 125, 214, 30),
						new Color(129, 126, 214, 50),
						new Color(126, 179, 214, 90),
						new Color(187, 126, 214, 40),
						new Color(127, 126, 150, 55),
						new Color(214, 199, 126),
						new Color(129, 127, 113)
				));
		field3.setCircularOrbit(star, 0, 0, 250);

		//void setTerrainName()

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				"Rabarbaran", // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy", // type of object, defined in custom_entities.json
				"pirates"); // faction
		don_eladio.setCircularOrbitPointingDown(star, -60, 6600, 100);

		SectorEntityToken don_eladio_2 = system.addCustomEntity("don_eladio_2", // unique id
				"Ovonokin Absest", // name - if null, defaultName from custom_entities.json will be used
				"sensor_array", // type of object, defined in custom_entities.json
				"pirates"); // faction
		don_eladio_2.setCircularOrbitPointingDown(star, 120, 10600, 205);

		PlanetAPI prototype = system.addPlanet("prototype", star, "Prototype", "fire_giant", 50, 480, 8600, 400);

		PlanetAPI hoppler = system.addPlanet("hoppler", prototype, "Hoppler", "lava", -12, 80, 880, 44);
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(200f, // terrain effect band width
						200, // terrain effect middle radius
						hoppler, // entity that it's around
						100f, // visual band start
						300f, // visual band end
						new Color(43, 203, 255, 40), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(25, 115, 145, 30),
						new Color(30, 141, 179, 50),
						new Color(36, 168, 212, 90),
						new Color(42, 195, 246, 40),
						new Color(43, 135, 255, 55),
						new Color(43, 255, 168),
						new Color(43, 255, 240)
				));
		field.setCircularOrbit(hoppler, 0, 0, 30);

		PlanetAPI bullup = system.addPlanet("bullup", star, "Bullup", "fire_giant", -400, 480, 12300, 650);
		SectorEntityToken field2 = system.addTerrain(Terrain.MAGNETIC_FIELD,
		new MagneticFieldParams(300f, // terrain effect band width
				800, // terrain effect middle radius
				bullup, // entity that it's around
				500f, // visual band start
				1100f, // visual band end
				new Color(43, 203, 255, 40), // base color
				1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
				new Color(25, 115, 145, 30),
				new Color(30, 141, 179, 50),
				new Color(36, 168, 212, 90),
				new Color(42, 195, 246, 40),
				new Color(43, 135, 255, 55),
				new Color(43, 255, 168),
				new Color(43, 255, 240)
		));
		field2.setCircularOrbit(bullup, 0, 0, 130);

		PlanetAPI night_night = system.addPlanet("night_night", star, "Night Night", "toxic", -200, 180, 15600, 850);
		SectorEntityToken gizmo = system.addCustomEntity("gizmo", "Gizmo Aterra", "station_side02", "pirates");
		gizmo.setCircularOrbitPointingDown(system.getEntityById("night_night"), 30, 600, 100);
		gizmo.setCustomDescriptionId("station_gizmo");
		gizmo.setInteractionImage("illustrations", "pirate_station");

		JumpPointAPI night_night_jump = Global.getFactory().createJumpPoint("night_night_jump", "Night Night Jump-point");
		night_night_jump.setCircularOrbit(system.getEntityById("Horozit"), 200, 15600, 850);
		night_night_jump.setRelatedPlanet(night_night);

		night_night_jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(night_night_jump);

		SectorEntityToken asteroid_field = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						200f, // min radius
						300f, // max radius
						8, // min asteroid count
						12, // max asteroid count
						4f, // min asteroid radius
						12f, // max asteroid radius
						"Night Night Lagrange Point Omega")); // null for default name
		asteroid_field.setCircularOrbit(star, 200, 15600, 850);

		SectorEntityToken asteroid_field2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						500f, // min radius
						600f, // max radius
						10, // min asteroid count
						15, // max asteroid count
						8f, // min asteroid radius
						16f, // max asteroid radius
						"Deathpoint Lagrange Alfa")); // null for default name
		asteroid_field2.setCircularOrbit(star, 0, 15600, 850);

		PlanetAPI robert_gailer = system.addPlanet("robert_gailer", star, "Robert Gailer", "arid", 900, 140, 19600, 1200);
		robert_gailer.setCustomDescriptionId("planet_robert_gailer");
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
