package data.shipsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

public class AmmoFeedStats extends BaseShipSystemScript {

	public static final float ROF_BONUS = 1f;
	public static final float AMMO_REGEN_BONUS = 100f;
	public static final float FLUX_REDUCTION = 30f;
	
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		
		float mult = 1f + ROF_BONUS * effectLevel;
		stats.getBallisticRoFMult().modifyMult(id, mult);
		stats.getBallisticWeaponFluxCostMod().modifyMult(id, 1f - (FLUX_REDUCTION * 0.01f));
		stats.getBallisticAmmoRegenMult().modifyPercent(id, AMMO_REGEN_BONUS);
		
//		ShipAPI ship = (ShipAPI)stats.getEntity();
//		ship.blockCommandForOneFrame(ShipCommand.FIRE);
//		ship.setHoldFireOneFrame(true);
	}
	public void unapply(MutableShipStatsAPI stats, String id) {
		stats.getBallisticRoFMult().unmodify(id);
		stats.getBallisticWeaponFluxCostMod().unmodify(id);
		stats.getBallisticAmmoRegenMult().unmodify(id);
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		float mult = 1f + ROF_BONUS * effectLevel;
		float bonusPercent = (int) (mult * 100f);
		if (index == 0) {
			return new StatusData("Firerate " + (int) bonusPercent + "%", false);
		}
		if (index == 1) {
			return new StatusData("Flux Consumption " + (int) (0 - FLUX_REDUCTION) + "%", false);
		}
		if (index == 2) {
			return new StatusData("Reloading " + (int) (100 + AMMO_REGEN_BONUS) + "%", false);
		}
		return null;
	}
}
