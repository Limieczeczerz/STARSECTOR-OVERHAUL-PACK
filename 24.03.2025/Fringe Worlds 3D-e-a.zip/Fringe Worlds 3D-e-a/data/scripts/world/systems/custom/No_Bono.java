package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class No_Bono {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("No Bono");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("no_bono", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				520f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(181, 29, 156)); // light color in entire system, affects all entities

		PlanetAPI planet_null = system.addPlanet("planet_null", star, "Null", "desert1", 0, 160, 1500, 80);
		planet_null.setCustomDescriptionId("planet_null");

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint_null", "Devoid");
		jumpPoint.setCircularOrbit( star, 150, 4800, 290);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);
		jumpPoint.setRelatedPlanet(planet_null);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				1, 2, // min/max entities to add
				8000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		//JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_null", "Path Laid");
		//jumpPoint_extra.setCircularOrbit( star, 300-120, 12000, 600);
		//jumpPoint_extra.setStandardWormholeToHyperspaceVisual();
		//system.addEntity(jumpPoint_extra);

		SectorEntityToken empty = system.addCustomEntity("empty", // unique id
				"Point Hyperstop", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"sindrian_diktat"); // faction
		empty.setCircularOrbitPointingDown(star, 300+120, 15000, 800);

		PlanetAPI forbidden = system.addPlanet("forbidden", star, "Forbidden", "ice_giant", 400, 300, 15000, 800);

			PlanetAPI fameless = system.addPlanet("fameless", forbidden, "Fameless", "toxic_cold", 80, 60, 800, 50);
			fameless.setCustomDescriptionId("planet_fameless");

			PlanetAPI alone = system.addPlanet("alone", forbidden, "Alone", "frozen", 0, 80, 1200, 70);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
