package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;

public class Deathcon {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Deathcon");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background3.jpg");

		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("deathcon", "black_hole", 900f, 0);
		StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
		system.removeEntity(coronaPlugin.getEntity());

		system.addCorona(star, Terrain.EVENT_HORIZON,
				2000f, // radius outside planet
				-10f, // burn level of "wind"
				0f, // flare probability
				25f // CR loss mult while in it
		);

		system.setLightColor(new Color(250, 134, 67)); // light color in entire system, affects all entities

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.OLD,
				1, 1, // min/max entities to add
				3000, // radius to start adding at
				4, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		SectorEntityToken meridia = system.addCustomEntity("meridia", "Ghost of Meridia", "station_hightech3", "tritachyon");
		meridia.setCircularOrbitPointingDown(system.getEntityById("deathcon"), 30, 7300, 300);
		meridia.setCustomDescriptionId("station_meridia");
		meridia.setInteractionImage("illustrations", "cargo_loading");

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Deathcon Entrance");
		jumpPoint_extra.setCircularOrbit(star, -140, 8600, 400);
		system.addEntity(jumpPoint_extra);

		PlanetAPI gimli = system.addPlanet("gimli", star, "Gimli", "desert_cold", -290, 110, 10500, 520);
		gimli.setCustomDescriptionId("planet_gimli");

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14500, 850, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 15800, 800, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 16200, 820, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 18500, 950, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 19800, 900, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 20000, 820, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 20800, 1000, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 21000, 820, Terrain.RING, null);

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				"Rollerblade", // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		don_eladio.setCircularOrbitPointingDown(star, 600, 8500, 1205);

		SectorEntityToken don_eladio_2 = system.addCustomEntity("don_eladio_2", // unique id
				"Obisidian Communicatory", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		don_eladio_2.setCircularOrbitPointingDown(star, -120, 20600, 820);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);

		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
