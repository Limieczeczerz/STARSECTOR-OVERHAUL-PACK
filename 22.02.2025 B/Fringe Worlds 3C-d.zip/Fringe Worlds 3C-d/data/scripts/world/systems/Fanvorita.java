package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

public class Fanvorita {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Fanvorita");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("fanvorita", // unique id for star
				"star_green", // id in planets.json
				900f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				5f, // solar wind burn level
				1f, // flare probability
				2f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(140, 255, 180)); // light color in entire system, affects all entities


		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "stable_location", Factions.NEUTRAL);
		don_eladio.setCircularOrbitPointingDown( star, 90 + 60, 3200, 100);

		// Moon of syrinx w/ ship-wrecking & industrial stuff
		PlanetAPI sobriety = system.addPlanet("sobriety", star, "Sobriety", "rocky_metallic", 90, 195, 3000, 230);
		sobriety.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		sobriety.getSpec().setGlowColor(new Color(183,250,191,100) );
		sobriety.getSpec().setUseReverseLightForGlow(true);
		sobriety.applySpecChanges();

		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						400, // terrain effect middle radius
						sobriety, // entity that it's around
						200f, // visual band start
						600f, // visual band end
						new Color(189, 79, 57, 50), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(125, 52, 37, 30),
						new Color(196, 82, 59, 50),
						new Color(255, 106, 77, 90),
						new Color(255, 140, 117, 140),
						new Color(184, 84, 72, 155),
						new Color(186, 50, 24),
						new Color(156, 43, 20)
				));
		field.setCircularOrbit(sobriety, 0, 0, 50);

		PlanetAPI vengeance = system.addPlanet("vengeance", star, "Vengeance", "rocky_unstable", 180+60, 125, 5000, 550);

		JumpPointAPI jump = Global.getFactory().createJumpPoint("jump", "Vengeance Jump-point");
		jump.setCircularOrbit(system.getEntityById("fanvorita"), 80, 6000, 400);
		jump.setRelatedPlanet(vengeance);
		jump.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jump);

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, new Color(170,210,255,255), 256f, 8000, 400f, Terrain.RING, null);
		system.addAsteroidBelt(star, 200, 8000, 128, 400, 800, Terrain.ASTEROID_BELT, "Field of Nuah");
		PlanetAPI tiny_person = system.addPlanet("tiny_person", star, "Tiny Person", "water", -180, 30, 7800, 420);
		tiny_person.setCustomDescriptionId("planet_tiny_person");

		PlanetAPI resendance = system.addPlanet("resendance", star, "Resendance", "rocky_ice", -180, 130, 10000, 550);

		system.autogenerateHyperspaceJumpPoints(true, true);
	}
		
	
}
