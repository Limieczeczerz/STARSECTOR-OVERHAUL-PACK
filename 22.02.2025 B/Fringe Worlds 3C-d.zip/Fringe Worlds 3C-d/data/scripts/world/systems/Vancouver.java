package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

public class Vancouver {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Vancouver");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		PlanetAPI star = system.initStar("vancouver", // unique id for this star
				"star_orange_giant", // id in planets.json
				1450f,		// radius (in pixels at default zoom)
				1000, // corona radius, from star edge
				5f, // solar wind burn level
				1f, // flare probability
				2f); // cr loss mult
		system.setLightColor(new Color(202, 131, 131)); // light color in entire system, affects all entities

		PlanetAPI rocketger = system.addPlanet("rocketger", star, "Rocketger", "rocky_metallic", 50, 180, 2900, 220);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Entrance Moggato");
		jumpPoint.setCircularOrbit( star, 360, 4000, 180);
		jumpPoint.setRelatedPlanet(rocketger);
		system.addEntity(jumpPoint);

		PlanetAPI abraham_newelles = system.addPlanet("abraham_newelles", star, "Abraham Newelles", "rocky_unstable", 40, 140, 8600, 500);
		abraham_newelles.setCustomDescriptionId("planet_abraham_newelles");

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Entrance Obonit");
		jumpPoint_extra.setCircularOrbit( star, 360, 9200, 360);
		jumpPoint_extra.setRelatedPlanet(abraham_newelles);
		system.addEntity(jumpPoint_extra);

		PlanetAPI brumingham = system.addPlanet("brumingham", star, "Brumingham", "barren-desert", 200, 140, 10200, 720);
		brumingham.setCustomDescriptionId("planet_brumingham");
		brumingham.setInteractionImage("illustrations", "city_from_above");
		brumingham.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		brumingham.getSpec().setGlowColor(new Color(197,34,245,255));
		brumingham.getSpec().setUseReverseLightForGlow(true);
		brumingham.applySpecChanges();

		SectorEntityToken forward_port = system.addCustomEntity("forward_port", // unique id
				"God Bless the Soul of Patriot", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"neutral"); // faction
		forward_port.setCircularOrbitPointingDown(star, 60, 6000, 200);

		SectorEntityToken abynit = system.addCustomEntity("abynit", // unique id
				"Zone Forbidden", // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"neutral"); // faction
		abynit.setCircularOrbitPointingDown(star, 250, 8800, 500);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 11570, 820f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 11660, 720f, null, null);
		system.addAsteroidBelt(star, 150, 11600, 170, 200, 250, Terrain.ASTEROID_BELT, "Moron's End");

		SectorEntityToken thule_pirate_station = system.addCustomEntity("darknight_pirate_station",
				"Darknight Cthullu Forbiddance", "station_side00", "pirates");

		thule_pirate_station.setCircularOrbitPointingDown( star, -240, 14900, 800);
		thule_pirate_station.setCustomDescriptionId("darknight_pirate_station");
		thule_pirate_station.setInteractionImage("illustrations", "pirate_station");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 14500, 650, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 14800, 700, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 15000, 720, Terrain.RING, null);


		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				4, 5, // min/max entities to add
				16000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds
		
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
