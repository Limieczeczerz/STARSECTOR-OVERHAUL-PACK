package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

public class Askonia {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Askonia");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
		//system.getMemoryWithoutUpdate().set(MusicPlayerPluginImpl.MUSIC_SET_MEM_KEY, "music_title");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("askonia", // unique id for this star 
										 StarTypes.RED_SUPERGIANT, // id in planets.json
										 1800f,		// radius (in pixels at default zoom)
										 1000, // corona radius, from star edge
										 5f, // solar wind burn level
										 1f, // flare probability
										 2f); // cr loss mult
		
		system.setLightColor(new Color(201, 86, 56)); // light color in entire system, affects all entities

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);
		
		PlanetAPI a1 = system.addPlanet("sindria", star, "Sindria", "rocky_metallic", 0, 150, 4900, 200);
		a1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		a1.getSpec().setGlowColor(new Color(255,255,255,255));
		a1.getSpec().setUseReverseLightForGlow(true);
		a1.applySpecChanges();
		a1.setCustomDescriptionId("planet_sindria");
		a1.setInteractionImage("illustrations", "sindria");

		SectorEntityToken station = system.addCustomEntity("diktat_cnc", "Command & Control", "station_side02", "sindrian_diktat");
		station.setCircularOrbitPointingDown(system.getEntityById("sindria"), 45, 300, 50);
		station.setInteractionImage("illustrations", "orbital");
//		station.setCustomDescriptionId("station_ragnar");

		SectorEntityToken sindria_relay = system.addCustomEntity("sindria_relay", // unique id
				"Sindria Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"sindrian_diktat"); // faction
		sindria_relay.setCircularOrbitPointingDown( system.getEntityById("askonia"), -60, 5100, 210);
		
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("askonia_jump_point_alpha", "Sindria Jump-point");
			OrbitAPI orbit = Global.getFactory().createCircularOrbit(a1, 0, 4500, 280);
			jumpPoint.setOrbit(orbit);
			jumpPoint.setRelatedPlanet(a1);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			jumpPoint.setCircularOrbit( system.getEntityById("askonia"), 60, 5570, 400);
			system.addEntity(jumpPoint);
		
		// And now, the outer system.
			system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 5570, 170f, null, null);
			system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 5660, 176f, null, null);
		system.addAsteroidBelt(star, 150, 5600, 170, 200, 250, Terrain.ASTEROID_BELT, "Stone River");
		
	// Salus system
		PlanetAPI a2 = system.addPlanet("salus", star, "Salus", "gas_giant", 230, 450, 12500, 610);
		a2.setCustomDescriptionId("planet_salus");
		a2.getSpec().setPlanetColor(new Color(255,225,170,255));
		a2.getSpec().setAtmosphereColor(new Color(160,110,45,140));
		a2.getSpec().setCloudColor(new Color(255,164,96,200));
		a2.getSpec().setTilt(15);
		a2.applySpecChanges();
		
			PlanetAPI a2a = system.addPlanet("cruor", a2, "Cruor", "rocky_unstable", 45, 40, 700, 25);
			a2a.setInteractionImage("illustrations", "desert_moons_ruins");
			a2a.setCustomDescriptionId("planet_cruor");
			
			//system.addAsteroidBelt(a2, 50, 1100, 128, 40, 80, Terrain.ASTEROID_BELT, "Opis Ring");
			//system.addRingBand(a2, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 1100, 40f);
			//system.addRingBand(a2, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1120, 50f);
			//system.addRingBand(a2, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1100, 80f);
			
			SectorEntityToken opis_debris_cloud = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
					200f, // min radius
					400f, // max radius
					20, // min asteroid count
					30, // max asteroid count
					4f, // min asteroid radius 
					12f, // max asteroid radius
					"Opis Debris Cloud")); // null for default name
			opis_debris_cloud.setCircularOrbitPointingDown(system.getEntityById("salus"), 45, 1100, 70);	
			
			PlanetAPI a2b = system.addPlanet("volturn", a2, "Volturn", "water", 110, 100, 1400, 45);
			a2b.setCustomDescriptionId("planet_volturn");
			a2b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
			a2b.getSpec().setGlowColor(new Color(255,255,255,255));
			a2b.getSpec().setUseReverseLightForGlow(true);
			a2b.applySpecChanges();
			a2b.setInteractionImage("illustrations", "volturn");
			
				// Salus nav buoy, in L5
				SectorEntityToken salus_nav = system.addCustomEntity(null, "Salus Navigation Buoy", "nav_buoy_makeshift", Factions.DIKTAT);
				salus_nav.setCircularOrbitPointingDown(star, 230, 8400, 610);

		system.addRingBand(a2, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 70f);
		system.addRingBand(a2, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 90f);
		system.addRingBand(a2, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 110f, Terrain.RING, "Dust Ring");

		//NEED MORE SPACE!!!
		//TOO HOT!!!
		//AAAAAAAAAAAAH TOO MUCH STUFF
		//system.addRingBand(a2, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 50f);
		//system.addRingBand(a2, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 70f);
		//system.addRingBand(a2, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 80f);
		//system.addRingBand(a2, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 2150, 90f, Terrain.RING, "Cloud Ring");

		// Askonia Gate
		SectorEntityToken askonia_gate = system.addCustomEntity("askonia_gate", // unique id
				"Askonia Gate", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		askonia_gate.setCircularOrbit(star, 230-180, 7000, 230);
		
		// Nortia - Independent (Charterist) base - caught in Salus' L4
			PlanetAPI a3 = system.addPlanet("nortia", star, "Nortia", "barren-bombarded", 230 + 80, 80, 12500, 610);
			a3.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
			a3.getSpec().setGlowColor(new Color(255,255,255,255));
			a3.getSpec().setUseReverseLightForGlow(true);
			a3.applySpecChanges();
			a3.setInteractionImage("illustrations", "hound_hangar");
			a3.setCustomDescriptionId("planet_nortia");
			
			// Salus trojans
			SectorEntityToken salusL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Salus L4 Asteroids")); // null for default name
			
			SectorEntityToken salusL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius 
						16f, // max asteroid radius
						"Salus L5 Asteroids")); // null for default name
			
			salusL4.setCircularOrbit(star, 230 + 80, 12500, 610);
			salusL5.setCircularOrbit(star, 230 - 80, 12500, 610);
			
			// Askonia Outer Jump (in Salus L5)
			JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("salus_jump", "Salus L5 Jump-point");
			jumpPoint2.setCircularOrbit(star, 230 - 80, 12500, 610);
			jumpPoint2.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint2);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				2, 3, // min/max entities to add
				16000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds


		// Umbra - the resistance (or pirates)
		PlanetAPI a4 = system.addPlanet("umbra", star, "Umbra", "rocky_ice", 280, 150, 22500, 1200);
		a4.setCustomDescriptionId("planet_umbra");
		a4.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		a4.getSpec().setGlowColor(new Color(255,255,255,255));
		a4.getSpec().setUseReverseLightForGlow(true);
		a4.applySpecChanges();
		a4.setInteractionImage("illustrations", "pirate_station");

		// makeshift sensor array in counter-orbit to Umbra
		SectorEntityToken askonia_outer_array = system.addCustomEntity(null, "Askonia Fringe Listening Station", "sensor_array_makeshift", Factions.PIRATES);
		askonia_outer_array.setCircularOrbitPointingDown(star, 300, 22000, 1000);
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
	

	
}
