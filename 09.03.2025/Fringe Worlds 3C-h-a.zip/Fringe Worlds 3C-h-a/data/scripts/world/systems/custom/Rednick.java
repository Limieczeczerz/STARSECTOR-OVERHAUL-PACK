package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.DerelictThemeGenerator;

import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin.DerelictShipData;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner.ShipRecoverySpecialCreator;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.BaseSalvageSpecial;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.PerShipData;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipCondition;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Rednick {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Rednick");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");
		
		PlanetAPI star = system.initStar("rednick",
				"star_white",  // id in planets.json
				380f, 		  // radius (in pixels at default zoom)
				600, // corona radius, from star edge
				5f, // solar wind burn level
				1f, // flare probability
				2f); // cr loss mult

		system.setLightColor(new Color(202, 222, 250)); // light color in entire system, affects all entities

		//system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1200, 50, Terrain.RING, null);
		//system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1500, 40, Terrain.RING, null);

		system.addAsteroidBelt(star, 50, 1300, 200, 290, 310, Terrain.ASTEROID_BELT,  null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1200, 305f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 1200, 295f, null, null);

		system.addAsteroidBelt(star, 50, 1600, 200, 290, 310, Terrain.ASTEROID_BELT,  null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1500, 305f, null, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 1500, 295f, null, null);

		PlanetAPI wunderschnitzer = system.addPlanet("wunderschnitzer", star, "Wunderschnitzer", "lava_minor", 60, 140, 3000, 120);
		wunderschnitzer.setCustomDescriptionId("planet_wunderschnitzer");

		SectorEntityToken empty_a = system.addCustomEntity("empty_a", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"pirates"); // faction
		empty_a.setCircularOrbitPointingDown(system.getEntityById("rednick"), 100, 3000, 120);

		JumpPointAPI jump_point = Global.getFactory().createJumpPoint("jump_point", "Orbital Balmington");
		jump_point.setCircularOrbit(system.getEntityById("rednick"), -20, 3000, 120);
		jump_point.setRelatedPlanet(wunderschnitzer);
		jump_point.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jump_point);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 4200, 250, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 4500, 240, Terrain.RING, null);

		PlanetAPI greenberry = system.addPlanet("greenberry", star, "Greenberry", "ice_giant", 120, 340, 6300, 240);
		system.addRingBand(greenberry, "misc", "rings_special0", 256f, 2, Color.white, 256f, 1000, 50, Terrain.RING, null);
		system.addRingBand(greenberry, "misc", "rings_special0", 256f, 2, Color.white, 256f, 1100, 64, Terrain.RING, null);
		//system.addRingBand(greenberry, "misc", "rings_special0", 256f, 2, Color.white, 256f, 1400, 32, Terrain.RING, null);

		SectorEntityToken blueberryL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						4f, // min asteroid radius
						16f, // max asteroid radius
						"Blueberry L4 Asteroids")); // null for default name

		SectorEntityToken blueberryL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						1000f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						10f, // min asteroid radius
						30f, // max asteroid radius
						"Blueberry L5 Asteroids")); // null for default name

		blueberryL4.setCircularOrbit(star, 120 + 80, 6300, 240);
		blueberryL5.setCircularOrbit(star, 120 - 80, 6300, 240);

		SectorEntityToken empty_b = system.addCustomEntity("empty_b", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"pirates"); // faction
		empty_b.setCircularOrbitPointingDown(system.getEntityById("rednick"), 120 + 80, 6300, 240);

		PlanetAPI blue_corporate = system.addPlanet("blue_corporate", star, "Blue Corporate", "barren", 120 - 80, 60, 6300, 240);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 8200, 420, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 8500, 460, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 8200, 440, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 8500, 480, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11200, 520, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11500, 560, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11200, 540, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11500, 580, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12100, 770, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12600, 710, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12200, 740, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12400, 780, Terrain.RING, null);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);

		addDerelict(system, star, "conquest_Elite", ShipCondition.BATTERED, 12000f, false);
		addDerelict(system, star, "gryphon_FS", ShipCondition.BATTERED, 12700f, false);
		addDerelict(system, star, "heron_Strike", ShipCondition.BATTERED, 13000f, false);
		addDerelict(system, star, "heron_Strike", ShipCondition.BATTERED, 13500f, false);
		addDerelict(system, star, "brawler_Support", ShipCondition.BATTERED, 13750f, false);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);
	}

	protected void addDerelict(StarSystemAPI system, SectorEntityToken focus, String variantId,
							   ShipCondition condition, float orbitRadius, boolean recoverable) {
		DerelictShipData params = new DerelictShipData(new PerShipData(variantId, condition, 0f), false);
		SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
		ship.setDiscoverable(true);

		float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
		ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);

		if (recoverable) {
			ShipRecoverySpecialCreator creator = new ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
			Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
		}
	}
	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}

	
}









