package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Vobo {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Vobo");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");

		PlanetAPI star = system.initStar("vobo", "star_purple_giant", 1620, 2000, 20f, 2f, 8f);

		system.setLightColor(new Color(236, 191, 255)); // light color in entire system, affects all entities

		SectorEntityToken overlord_broadcast = system.addCustomEntity("overlord_broadcast", // unique id
				"Overlord Broadcast Station", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		overlord_broadcast.setCircularOrbitPointingDown(star, -60, 6600, 100);

		JumpPointAPI jumppoint_oro = Global.getFactory().createJumpPoint("jumppoint_oro", "Jump-Point Oro");
		jumppoint_oro.setCircularOrbit(system.getEntityById("Vobo"), 100, 10200, 450);

		jumppoint_oro.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumppoint_oro);

		PlanetAPI broken_bone = system.addPlanet("broken_bone", star, "Broken Bone", "lava", 120, 200, 13950, 420);

		PlanetAPI rippers_morld = system.addPlanet("rippers_morld", star, "Ripper's Morld", "water", 0, 140, 15880, 600);
		rippers_morld.setCustomDescriptionId("planet_rippers_morld");
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(100f, // terrain effect band width
						200, // terrain effect middle radius
						rippers_morld, // entity that it's around
						150f, // visual band start
						250f, // visual band end
						new Color(25, 77, 145, 40), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(25, 77, 145, 130),
						new Color(25, 92, 179, 150),
						new Color(36, 112, 212, 190),
						new Color(42, 130, 245, 140),
						new Color(43, 68, 255, 155),
						new Color(43, 255, 239),
						new Color(43, 201, 255)
				));
		field.setCircularOrbit(rippers_morld, 0, 0, 30);

		SectorEntityToken shade = system.addCustomEntity("eventide_mirror1", "Shield Alpha-Omega", "stellar_shade", "tritachyon");
		shade.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180, 400, 600);
		shade.setCustomDescriptionId("stellar_shade");

		PlanetAPI old_bob = system.addPlanet("old_bob", star, "Old Bob", "barren-bombarded", -440, 150, 18880, 840);
		old_bob.setCustomDescriptionId("planet_old_bob");

		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
