package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Cappuccino {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Cappuccino");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		SectorEntityToken hybrasil_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/hybrasil_nebula.png",
				0, 0, // center of nebula
				system, // location to add to
				"terrain", "nebula", // "nebula_blue", // texture to use, uses xxx_map for map
				4, 4, StarAge.AVERAGE); // number of cells in texture
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("cappuccino", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				500f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(162, 29, 155)); // light color in entire system, affects all entities

		//system is too crowded, removing these. Brown giant shouldn't have that much shit going on
		//system.addRingBand(star, "misc", "rings_special0", 256f, 1, new Color(255,255,255,200), 256f, 2700, 100f, Terrain.RING, null);
		//system.addRingBand(star, "misc", "rings_special0", 256f, 1, new Color(255,255,255,200), 256f, 3000, 100f, Terrain.RING, null);
		
		PlanetAPI gumbat = system.addPlanet("gumbat", star, "Gumbat", "toxic", 50, 130, 1500, 100);
		gumbat.setCustomDescriptionId("planet_gumbat");
		gumbat.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		gumbat.getSpec().setGlowColor(new Color(181,29,35,155));
		gumbat.getSpec().setPitch(20f);
		gumbat.getSpec().setUseReverseLightForGlow(true);
		gumbat.applySpecChanges();

		SectorEntityToken gumball_station = system.addCustomEntity("gumball_station", "Robyn Orbital", "station_side04", "tritachyon");
		gumball_station.setCircularOrbitPointingDown(system.getEntityById("Gumbat"), 0, 250, 15);
		gumball_station.setCustomDescriptionId("gumball_station");

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("gumbat_jump", "Espresso Jump-point");
		jumpPoint.setCircularOrbit( system.getEntityById("cappuccino"), 150, 3800, 250);
		system.addEntity(jumpPoint);
		jumpPoint.setStandardWormholeToHyperspaceVisual();

		jumpPoint.setRelatedPlanet(gumbat);

		PlanetAPI mambo = system.addPlanet("mambo", star, "Mambo", "rocky_ice", 0, 100, 10000, 1000);

		SectorEntityToken gumbat_relay = system.addCustomEntity("gumbat_relay", // unique id
				"Free TV Corporate Satellite", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		gumbat_relay.setCircularOrbitPointingDown(star, -120, 3200, 150);

		SectorEntityToken nothing = system.addCustomEntity("nothing", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		nothing.setCircularOrbitPointingDown(star, 250, 14000, 500);

		PlanetAPI grabuz = system.addPlanet("grabuz", star, "Grabuz", "ice_giant", 400, 320, 12000, 650);
		grabuz.setCustomDescriptionId("planet_grabuz");
		system.addRingBand(grabuz, "misc", "rings_ice0", 256f, 1, new Color(200,200,200,255), 256f, 800, 100f, Terrain.RING, null);
		system.addRingBand(grabuz, "misc", "rings_ice0", 256f, 1, new Color(200,200,200,255), 256f, 900, 100f, Terrain.RING, null);

		PlanetAPI sos = system.addPlanet("sos", star, "Song of Soul", "frozen", 800, 110, 13000, 1500);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);

		system.autogenerateHyperspaceJumpPoints(true, true);

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
