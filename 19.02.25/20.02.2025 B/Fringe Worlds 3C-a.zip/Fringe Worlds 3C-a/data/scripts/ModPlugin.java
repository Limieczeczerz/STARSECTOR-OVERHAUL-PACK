package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.LocationAPI;

//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
//import com.fs.starfarer.api.characters.ImportantPeopleAPI;
//import com.fs.starfarer.api.campaign.econ.MarketAPI;
//import com.fs.starfarer.api.characters.PersonAPI;
//import com.fs.starfarer.api.impl.campaign.ids.Factions;
//import com.fs.starfarer.api.impl.campaign.ids.Ranks;
//import com.fs.starfarer.api.impl.campaign.ids.Skills;
//import com.fs.starfarer.api.impl.campaign.ids.Commodities;
//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
//import com.fs.starfarer.api.campaign.PersonImportance;
//import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

//Gen 1
import data.scripts.world.systems.Parkapec;
import data.scripts.world.systems.Cappuccino;
import data.scripts.world.systems.Morokoon;
import data.scripts.world.systems.Syzygy;
import data.scripts.world.systems.Vancouver;
import data.scripts.world.systems.Moronia;
import data.scripts.world.systems.Abin_Cresc;
import data.scripts.world.systems.No_Bono;

//Gen 2
import data.scripts.world.systems.Generosity;
import data.scripts.world.systems.Horozit;
import data.scripts.world.systems.Fanvorita;
import data.scripts.world.systems.Deathcon;
import data.scripts.world.systems.Oppenheimer;
import data.scripts.world.systems.Bzabzen;
public class ModPlugin extends BaseModPlugin {

    public void onNewGame() {

        //gen 1
        new Parkapec().generate(Global.getSector());
        new Cappuccino().generate(Global.getSector());
        new Morokoon().generate(Global.getSector());
        new Syzygy().generate(Global.getSector());
        new Vancouver().generate(Global.getSector());
        new Moronia().generate(Global.getSector());
        new Abin_Cresc().generate(Global.getSector());
        new No_Bono().generate(Global.getSector());

        //gen 2
        new Generosity().generate(Global.getSector());
        new Horozit().generate(Global.getSector());
        new Fanvorita().generate(Global.getSector());
        new Deathcon().generate(Global.getSector());
        new Oppenheimer().generate(Global.getSector());
        new Bzabzen().generate(Global.getSector());

        LocationAPI hyper = Global.getSector().getHyperspace();

        SectorEntityToken self_exiled_label = hyper.addCustomEntity("self_exiled_label_id", null, "self_exiled_label", null);
        self_exiled_label.setFixedLocation(-21000, -9100);

        SectorEntityToken injustice_label = hyper.addCustomEntity("injustice_label_id", null, "injustice_label", null);
        injustice_label.setFixedLocation(-34000, 13000);
    }
}