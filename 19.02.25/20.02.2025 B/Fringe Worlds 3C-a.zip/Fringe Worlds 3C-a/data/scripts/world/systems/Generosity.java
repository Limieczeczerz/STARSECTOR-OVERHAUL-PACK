package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

public class Generosity {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Generosity");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("generosity", // unique id for this star
				"star_blue_giant",  // id in planets.json
				1520f,          // radius (in pixels at default zoom)
				1000, // corona radius, from star edge
				15f, // solar wind burn level
				3f, // flare probability
				2f); // cr loss mult
		
		system.setLightColor(new Color(225, 230, 242)); // light color in entire system, affects all entities

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		don_eladio.setCircularOrbitPointingDown(star, 10, 2600, 50);

		PlanetAPI prion = system.addPlanet("prion", star, "Prion", "fire_giant", 120, 475, 4000, 240);
		PlanetAPI lotus = system.addPlanet("lotus", prion, "Forge of Lotus", "lava2", 0, 95, 800, 45);
		lotus.setCustomDescriptionId("planet_lotus");

		SectorEntityToken prion_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(360f, // terrain effect band width
						720, // terrain effect middle radius
						prion, // entity that it's around
						480f, // visual band start
						1080f, // visual band end
						new Color(82, 156, 255, 30), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(255, 195, 82, 30),
						new Color(255, 139, 82, 50),
						new Color(255, 215, 82, 90),
						new Color(255, 169, 82, 40),
						new Color(255, 236, 82, 55),
						new Color(117, 82, 160),
						new Color(82, 102, 255)
				));
		prion_field.setCircularOrbit(prion, 0, 0, 100);

		PlanetAPI event = system.addPlanet("event", star, "Event", "rocky_metallic", 400, 170, 6200, 280);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Babko Blitzkins Jump-Point");
		jumpPoint.setCircularOrbit( star, 80, 7000, 200);
		jumpPoint.setRelatedPlanet(event);
		system.addEntity(jumpPoint);

		PlanetAPI horbinos = system.addPlanet("horbinos", star, "Horbinos", "gas_giant", 120, 470, 8200, 370);
		PlanetAPI german_ghoul = system.addPlanet("german_ghoul", horbinos, "German Ghoul", "barren_venuslike", 0, 60, 900, 35);
		PlanetAPI tonderilla = system.addPlanet("tonderilla", horbinos, "Tonderilla", "desert", 42, 80, 1050, 40);
		tonderilla.setCustomDescriptionId("planet_tonderilla");
		
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 11500, 256f);
		system.addAsteroidBelt(star, 256, 11500, 256, 256, 256, Terrain.ASTEROID_BELT, null);



		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				6, 10, // min/max entities to add
				14600, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
