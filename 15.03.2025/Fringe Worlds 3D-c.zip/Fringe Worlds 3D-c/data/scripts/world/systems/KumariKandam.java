//KumariKandam.javapackage data.scripts.world.systems;
package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;

public class KumariKandam {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Kumari Kandam");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI kumarikandam_star = system.initStar("kumarikandam", // unique id for this star 
											"star_orange", // id in planets.json
											1100f,		// radius (in pixels at default zoom)
											1000, // corona radius, from star edge
											10f, // solar wind burn level
											1f, // flare probability
											3f); // cr loss mult
		
		system.setLightColor(new Color(212, 144, 151)); // light color in entire system, affects all entities

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);
		
		PlanetAPI kumarikandam_b = system.addPlanet("kumari_aru", kumarikandam_star, "Kumari Aru", "gas_giant", 240, 410, 8800, 350);
		kumarikandam_b.getSpec().setPlanetColor(new Color(150,235,245,255));
		kumarikandam_b.getSpec().setAtmosphereColor(new Color(150,170,240,150));
		kumarikandam_b.getSpec().setCloudColor(new Color(180,250,240,200));
		kumarikandam_b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		kumarikandam_b.getSpec().setGlowColor(new Color(250,50,105,100));
		kumarikandam_b.getSpec().setUseReverseLightForGlow(true);
		kumarikandam_b.getSpec().setIconColor(new Color(180,255,225,255));
		kumarikandam_b.applySpecChanges();
		kumarikandam_b.setCustomDescriptionId("planet_kumari_aru");

		Misc.initConditionMarket(kumarikandam_b);
		kumarikandam_b.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		kumarikandam_b.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);
		kumarikandam_b.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
		kumarikandam_b.getMarket().addCondition(Conditions.ORGANICS_ABUNDANT);
		kumarikandam_b.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		kumarikandam_b.getMarket().addCondition(Conditions.HOT);
		kumarikandam_b.getMarket().addCondition(Conditions.HIGH_GRAVITY);
		
		
			// Beholder Station
			SectorEntityToken beholder_station = system.addCustomEntity("beholder_station", "Beholder Station", "station_side05", "luddic_church");
			beholder_station.setCircularOrbitPointingDown(system.getEntityById("kumari_aru"), 0, 480, 20);
			beholder_station.setCustomDescriptionId("station_beholder");
			beholder_station.setInteractionImage("illustrations", "luddic_shrine");
			
			// And the moons of Kumari Aru
			// Makal : sulphurous outgassing like Io
			PlanetAPI kumarikandam_b1 = system.addPlanet("makal", kumarikandam_b, "Makal", "rocky_unstable", -20, 40, 550, 30);

			PlanetAPI kumarikandam_b2 = system.addPlanet("kulantai", kumarikandam_b, "Kulantai", "desert", 40, 80, 800, 50);
				Misc.initConditionMarket(kumarikandam_b2);
				kumarikandam_b2.getMarket().addCondition(Conditions.FARMLAND_POOR);
				kumarikandam_b2.getMarket().addCondition(Conditions.RARE_ORE_ABUNDANT);
				kumarikandam_b2.getMarket().addCondition(Conditions.ORE_RICH);
				kumarikandam_b2.getMarket().addCondition(Conditions.EXTREME_TECTONIC_ACTIVITY);
				kumarikandam_b2.getMarket().addCondition(Conditions.VERY_HOT);
				kumarikandam_b2.getMarket().addCondition(Conditions.LOW_GRAVITY);

			// Kumari Aru trojans - L4 leads, L5 follows
			SectorEntityToken kumari_aruL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						600f, // min radius
						1000f, // max radius
						16, // min asteroid count
						24, // max asteroid count
						8f, // min asteroid radius
						19f, // max asteroid radius
						"Kumari Aru L4 Asteroids")); // null for default name
			
			SectorEntityToken kumari_aruL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						600f, // min radius
						1000f, // max radius
						16, // min asteroid count
						24, // max asteroid count
						8f, // min asteroid radius
						18f, // max asteroid radius
						"Kumari Aru L5 Asteroids")); // null for default name
			
			kumari_aruL4.setCircularOrbit(kumarikandam_star, 240 + 60, 8800, 350);
			kumari_aruL5.setCircularOrbit(kumarikandam_star, 240 - 60, 8800, 350);

		PlanetAPI kanni = system.addPlanet("kanni", kumarikandam_star, "Kanni", "barren2", 240 - 60, 52, 8800, 350);
		kanni.setCustomDescriptionId("planet_kanni");
		kanni.setInteractionImage("illustrations", "mine");
			
			SectorEntityToken kumari_aru_l5_loc = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.LUDDIC_PATH); 
			kumari_aru_l5_loc.setCircularOrbitPointingDown(kumarikandam_star, 270 -60, 2800, 80);
		
		// counter-orbit sensor array
		SectorEntityToken chalcedon_loc = system.addCustomEntity(null, null, "nav_buoy_makeshift", Factions.PERSEAN); 
		chalcedon_loc.setCircularOrbitPointingDown(kumarikandam_star, 220-180, 4300, 180);
		
			// Destroyed station
			SectorEntityToken abandoned_station1 = system.addCustomEntity("abandoned_spacedock", "Abandoned Spacedock", "station_side00", "neutral");
			abandoned_station1.setInteractionImage("illustrations", "abandoned_station3");
			abandoned_station1.setCircularOrbitPointingDown(kumarikandam_star, 220 + 14, 4300, 180);
			abandoned_station1.setCustomDescriptionId("station_chalcedon");
		
			// fun debris
			DebrisFieldParams params = new DebrisFieldParams(
					200f, // field radius - should not go above 1000 for performance reasons
					-1f, // density, visual - affects number of debris pieces
					10000000f, // duration in days 
					0f); // days the field will keep generating glowing pieces
			
			params.source = DebrisFieldSource.SALVAGE;
			params.baseSalvageXP = 250; // base XP for scavenging in field
			SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
			SalvageSpecialAssigner.assignSpecialForDebrisField(debris);
			
			// makes the debris field always visible on map/sensors and not give any xp or notification on being discovered
			debris.setSensorProfile(null);
			debris.setDiscoverable(null);
			debris.setCircularOrbit(kumarikandam_star, 220 + 16, 4300, 180);
		
			// a gate in the Lagrangian of Chalcedon
			SectorEntityToken gate = system.addCustomEntity("kumari_gate", // unique id
					 "Kumarian Gate", // name - if null, defaultName from custom_entities.json will be used
					 "inactive_gate", // type of object, defined in custom_entities.json
					 null); // faction
			gate.setCircularOrbit(kumarikandam_star, 220-60, 4300, 180);
		
		
		system.addRingBand(kumarikandam_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 5900, 320f, null, null);
		system.addAsteroidBelt(kumarikandam_star, 150, 5900, 128, 300, 240, Terrain.ASTEROID_BELT, "The Mullam");

		JumpPointAPI jumpPoint0 = Global.getFactory().createJumpPoint("kumarikandam_jump", "Lumière Sacrée");
		jumpPoint0.setCircularOrbit(system.getEntityById("kumarikandam"), -50, 5500, 270);
		system.addEntity(jumpPoint0);

		system.addRingBand(kumarikandam_star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 13900, 600f, Terrain.RING, "The Hallam");
		system.addRingBand(kumarikandam_star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 14200, 620f, Terrain.RING, "The Hallam");

		PlanetAPI chalcedon = system.addPlanet("chalcedon", kumarikandam_star, "Chalcedon", "terran-eccentric", 220, 160, 14800, 540);
		//chalcedon.getSpec().setPlanetColor(new Color(225,169,154,255));
		//chalcedon.applySpecChanges();
		chalcedon.setCustomDescriptionId("planet_chalcedon");
		chalcedon.setInteractionImage("illustrations", "chalcedon");

		// a jump in the other one: Rama's Bridge :  Jump-point
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("kumarikandam_jump", "Rama's Bridge");
		jumpPoint2.setCircularOrbit( system.getEntityById("kumarikandam"), 220 + 60, 14800, 540);
		jumpPoint2.setRelatedPlanet(chalcedon);
		system.addEntity(jumpPoint2);
		
		PlanetAPI olinadu = system.addPlanet("olinadu", kumarikandam_star, "Olinadu", "cryovolcanic", 450, 160, 15500, 840);
		olinadu.setCustomDescriptionId("planet_olinadu");
		olinadu.setInteractionImage("illustrations", "cargo_loading");

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, kumarikandam_star, StarAge.AVERAGE,
		//		1, 2, // min/max entities to add
		//		18000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds
		
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
