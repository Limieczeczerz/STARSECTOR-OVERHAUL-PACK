package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Obediah {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Obediah");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background_galatia.jpg");

		//system.initNonStarCenter();

		PlanetAPI star = system.initStar("obediah", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				600f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(159, 29, 181)); // light color in entire system, affects all entities

		PlanetAPI orbinoptic = system.addPlanet("orbinoptic", star, "Orbinoptic", "toxic", 20, 140, 1900, 90);
		orbinoptic.setCustomDescriptionId("planet_orbinoptic");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 2400, 60f, Terrain.RING, null);

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		don_eladio.setCircularOrbitPointingDown(star, -120, 2400, 90);

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Inner Jump-point");
		jumpPoint_extra.setCircularOrbit(star, 60, 2800, 100);
		jumpPoint_extra.setRelatedPlanet(orbinoptic);
		system.addEntity(jumpPoint_extra);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 3, Color.white, 256f, 2800, 120f, Terrain.RING, null);

		PlanetAPI death_lord = system.addPlanet("death_lord", star, "Death Lord", "gas_giant", 100, 440, 5200, 350);
		death_lord.setCustomDescriptionId("planet_death_lord");
		death_lord.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		death_lord.getSpec().setGlowColor(new Color(123,95,134,155));
		death_lord.getSpec().setUseReverseLightForGlow(true);
		death_lord.applySpecChanges();
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(400f, // terrain effect band width
						700, // terrain effect middle radius
						death_lord, // entity that it's around
						500f, // visual band start
						900f, // visual band end
						new Color(123, 95, 134, 20), // base color
						1.5f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(190, 153, 247, 40),
						new Color(245, 174, 239, 40),
						new Color(170, 174, 245, 50),
						new Color(245, 174, 196, 50),
						new Color(149, 121, 160, 50),
						new Color(104, 69, 117),
						new Color(63, 32, 75)
				));
		field.setCircularOrbit(death_lord, 0, 0, 20);

		system.addRingBand(death_lord, "misc", "rings_special0", 256f, 3, Color.white, 256f, 1200, 50f, Terrain.RING, null);

		// Morn L5 cloud
		//SectorEntityToken nebula1 = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
		//		"      " +
		//				"xxxxxx" +
		//				"    xx" +
		//				"     x" +
		//				" x    " +
		//				"  xxx ",
		//		6, 6, // size of the nebula grid, should match above string
		//		"terrain", "nebula", 4, 4, "Indie_Mora L5 Cloud"));
		//nebula1.getLocation().set(death_lord.getLocation().x + 1000f, death_lord.getLocation().y);
		//nebula1.setCircularOrbit(star,
		//		death_lord.getCircularOrbitAngle() - 60f,
		//		death_lord.getCircularOrbitRadius(),
		//		390);

		// Morn L4 cloud
		//SectorEntityToken nebula2 = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
		//				"  x xx" +
		//				" xxx  " +
		//				"   xx " +
		//				"xxxxxx" +
		//				"  xx  " +
		//				" x    ",
		//		6, 6, // size of the nebula grid, should match above string
		//		"terrain", "nebula", 4, 4, "Indie_Mora L4 Cloud"));
		//nebula2.getLocation().set(death_lord.getLocation().x - 1000f, death_lord.getLocation().y);
		//nebula2.setCircularOrbit(star,
		//		death_lord.getCircularOrbitAngle() + 60f,
		//		death_lord.getCircularOrbitRadius(),
		//		390);

		SectorEntityToken don_eladio2 = system.addCustomEntity("don_eladio2", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		don_eladio2.getLocation().set(death_lord.getLocation().x - 1000f, death_lord.getLocation().y);
		don_eladio2.setCircularOrbit(star,
				death_lord.getCircularOrbitAngle() + 60f,
				death_lord.getCircularOrbitRadius(),
				390);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				3, 6, // min/max entities to add
				8000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
