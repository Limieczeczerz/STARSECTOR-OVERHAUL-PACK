package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Syzygy {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Syzygy");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("syzygy", // unique id for star
				"star_browndwarf", // id in planets.json
				500f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		system.setLightColor(new Color(176, 29, 155)); // light color in entire system, affects all entities

		PlanetAPI darth_idiot = system.addPlanet("darth_idiot", star, "Darth Idiot", "rocky_unstable", -20, 125, 1100, 50);

		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(500f, // terrain effect band width
						1500, // terrain effect middle radius
						star, // entity that it's around
						1200f, // visual band start
						2000f, // visual band end
						new Color(101, 165, 235, 50), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(122, 101, 235, 130),
						new Color(101, 123, 235, 150),
						new Color(101, 208, 235, 190),
						new Color(165, 101, 235, 240),
						new Color(115, 128, 192, 255),
						new Color(114, 120, 150),
						new Color(97, 119, 226)
				));
		field.setCircularOrbit(star, 0, 0, 120);
		
		PlanetAPI sobriety = system.addPlanet("sobriety", star, "Sobriety", "toxic", 0, 30, 2750, 120);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(155, 155, 255), 512f, 3000, 200f);
		system.addRingBand(star, "misc", "rings_asteroids0", 512f, 1, Color.white, 512f, 3000, 220f);
		system.addAsteroidBelt(star, 100, 3000, 500, 400, 300, Terrain.ASTEROID_BELT, "Myraa's Remnants");

		PlanetAPI gagner = system.addPlanet("gagner", star, "Gagner", "tundra", -100, 130, 4500, 280);
		gagner.setCustomDescriptionId("planet_gagner");
		gagner.setInteractionImage("illustrations", "industrial_megafacility");
		gagner.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		gagner.getSpec().setGlowColor(new Color(197,34,245,255));
		gagner.getSpec().setUseReverseLightForGlow(true);
		gagner.getSpec().setPitch(-20f);
		gagner.getSpec().setTilt(60f);
		gagner.applySpecChanges();

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Gaygan Jump-Point");
		jumpPoint.setCircularOrbit( star, 360, 2000, 104);
		jumpPoint.setRelatedPlanet(gagner);
		system.addEntity(jumpPoint);

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		relay.setCircularOrbitPointingDown(star, 0, 5600, 250);

		PlanetAPI bobit = system.addPlanet("bobit", star, "Bobit", "rocky_ice", -180, 145, 6820, 330);
		
		PlanetAPI memory = system.addPlanet("memory", star, "Memory", "frozen", 100, 120, 8800, 500);
		memory.setCustomDescriptionId("planet_memory");
		//memory.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "barren"));
		//memory.getSpec().setGlowColor(new Color(255,255,255,255));
		//memory.getSpec().setUseReverseLightForGlow(true);
		//memory.applySpecChanges();
		//Misc.initConditionMarket(memory);
		//memory.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
		//memory.getMarket().addCondition(Conditions.VOLATILES_ABUNDANT);
		//memory.getMarket().addCondition(Conditions.THIN_ATMOSPHERE);
		//memory.getMarket().addCondition(Conditions.COLD);
		//memory.getMarket().addCondition(Conditions.RUINS_WIDESPREAD);
		//memory.getMarket().getFirstCondition(Conditions.RUINS_WIDESPREAD).setSurveyed(true);

		SectorEntityToken memoryStation = system.addCustomEntity("memoryStation", "Koron Defense Port", "station_side06", "neutral");
		memoryStation.setCustomDescriptionId("station_memory");
		memoryStation.setCircularOrbitPointingDown(system.getEntityById("memory"), 0, 300, 50);

		//system.addRingBand(memory, "misc", "rings_special0", 256f, 30, Color.white, 256f, 600, 240f, Terrain.RING, "Amnesia");
		PlanetAPI memory_a = system.addPlanet("memory_a", memory, "Amnesia", "barren2", 300, 40, 510, 40);
		
		system.autogenerateHyperspaceJumpPoints(true, true);

		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
