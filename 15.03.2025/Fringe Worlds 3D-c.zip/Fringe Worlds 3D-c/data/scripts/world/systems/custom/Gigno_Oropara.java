package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Gigno_Oropara {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Gigno Oropara");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("gigno_oropara", // unique id for this star
				StarTypes.YELLOW, // id in planets.json
				1100f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				10f, // solar wind burn level
				1f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(250, 230, 95)); // light color in entire system, affects all entities

		PlanetAPI new_char = system.addPlanet("new_char", star, "New Char", "lava", 0, 180, 3500, 110);
		new_char.setCustomDescriptionId("planet_new_char");

		SectorEntityToken new_char_station = system.addCustomEntity("new_char_station", "New Char Military HQ", "station_lowtech1", Factions.HEGEMONY);
		new_char_station.setCircularOrbitPointingDown(new_char, 0, 300, 15);
		new_char_station.setInteractionImage("illustrations", "orbital");

		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.HEGEMONY);
		don_eladio.setCircularOrbitPointingDown(star, 270 - 60, 4400, 160);

		// Gate of Thule //Yes, I stole it... NO ONE WILL EVER KNOW!!!
		SectorEntityToken gate = system.addCustomEntity("gigno_opara_gate", // unique id
				"Gate of Gigno Opara", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(star, 270 + 60, 4400, 160);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Al Gebbar Jump-point");
		jumpPoint.setCircularOrbit(system.getEntityById("gigno_oropara"), 270 + 60, 5000, 225);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		jumpPoint.setRelatedPlanet(new_char);
		system.addEntity(jumpPoint);

		PlanetAPI mormons_rise = system.addPlanet("mormons_rise", star, "Mormon's Rise", "arid", 270, 140, 8000, 455);
		mormons_rise.setCustomDescriptionId("planet_mormons_rise");

		SectorEntityToken don_eladio_2 = system.addCustomEntity(null, null, "nav_buoy_makeshift", Factions.HEGEMONY);
		don_eladio_2.setCircularOrbitPointingDown(star, 90 + 60, 12400, 690);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11000, 1000, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11600, 950, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 11800, 970, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12400, 990, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12550, 1170, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 12800, 910, Terrain.RING, null);

		PlanetAPI frozone_b = system.addPlanet("frozone_b", star, "Mazomit", "gas_giant", 800, 490, 15000, 1500);
		PlanetAPI mimi = system.addPlanet("mimi", frozone_b, "Mimi", "toxic_cold", 150, 90, 1500, 53);
		PlanetAPI vandereer = system.addPlanet("vandereer", frozone_b, "Vandereer", "frozen2", -80, 110, 900, 42);
			
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
