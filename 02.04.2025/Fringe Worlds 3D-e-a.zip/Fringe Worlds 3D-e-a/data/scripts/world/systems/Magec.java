package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

public class Magec {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Magec");
		system.setType(StarSystemType.BINARY_FAR);
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		PlanetAPI star = system.initStar("magec", // unique id for this star
											"star_red_dwarf", // id in planets.json
											750f,		// radius (in pixels at default zoom)
											600, // corona radius, from star edge
											5f, // solar wind burn level
											1f, // flare probability
											2f); // cr loss mult

		system.setLightColor(new Color(250, 124, 67)); // light color in entire system, affects all entities
		
		PlanetAPI magec1 = system.addPlanet("chaxiraxi", star, "Chaxiraxi", "fire_giant", 50, 410, 2275, 80);
		magec1.getSpec().setPlanetColor(new Color(50,100,255,255));
		magec1.getSpec().setAtmosphereColor(new Color(120,130,100,150));
		magec1.getSpec().setCloudColor(new Color(195,230,255,200));
		magec1.getSpec().setIconColor(new Color(120,130,100,255));
		magec1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		magec1.getSpec().setGlowColor(new Color(235,38,8,145));
		magec1.getSpec().setUseReverseLightForGlow(true);
		magec1.getSpec().setAtmosphereThickness(0.5f);
		magec1.applySpecChanges();
		magec1.setCustomDescriptionId("planet_chaxiraxi");

		system.addCorona(magec1, Terrain.CORONA_AKA_MAINYU,
				300f, // radius outside planet
				5f, // burn level of "wind"
				0f, // flare probability
				1f // CR loss mult while in it
		);
		
		SectorEntityToken magec1_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
						new MagneticFieldParams(400f, // terrain effect band width
						600, // terrain effect middle radius
						magec1, // entity that it's around
						410f, // visual band start
						810f, // visual band end
						new Color(107, 95, 142, 30), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(97, 92, 109, 30),
						new Color(170, 130, 160, 50),
						new Color(71, 53, 62, 90),
						new Color(71, 63, 66, 40),
						new Color(71, 63, 66, 55),
						new Color(75, 0, 160), 
						new Color(127, 0, 255)
						));
			magec1_field.setCircularOrbit(magec1, 0, 0, 100);

		
		// And herrrrre's Achaman
		PlanetAPI magec3 = system.addPlanet("achaman", star, "Achaman", "star_white", 45, 200, 22000, 1420);
		system.setSecondary(magec3);
		system.addCorona(magec3, 600, 5f, 0.5f, 2f); // it's a very docile star.

		system.setSecondary(magec3);
		system.setType(StarSystemType.BINARY_FAR);

		SectorEntityToken nothing = system.addCustomEntity("nothing", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"stable_location", // type of object, defined in custom_entities.json
				"neutral"); // faction
		nothing.setCircularOrbitPointingDown(magec3, 22, 1500, 100);
		
		SectorEntityToken achaman_buoy = system.addCustomEntity("achaman_relay", // unique id
				 "Achaman Relay", // name - if null, defaultName from custom_entities.json will be used
				 "nav_buoy", // type of object, defined in custom_entities.json
				 "tritachyon"); // faction
		
		achaman_buoy.setCircularOrbitPointingDown( star, 45+60, 14500, 1390);
		
		PlanetAPI magec3a = system.addPlanet("tibicena", magec3, "Tibicena", "barren-bombarded", 200, 140, 2200, 160);
		magec3a.setCustomDescriptionId("planet_tibicena");
		magec3a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		magec3a.getSpec().setGlowColor(new Color(227,188,184,255));
		magec3a.getSpec().setUseReverseLightForGlow(true);
		magec3a.applySpecChanges();
		
			SectorEntityToken achaman_station = system.addCustomEntity("achaman_enterprise_station", 
																		"Achaman Enterprise Station",
																		"station_side04",
																		"tritachyon");
			
			achaman_station.setCircularOrbitPointingDown(system.getEntityById("tibicena"), 90, 250, 40);
			achaman_station.setCustomDescriptionId("station_achaman_enterprise");
			achaman_station.setInteractionImage("illustrations", "hound_hangar");
			
			
		// Asteroid belts; which I guess we're not doing in quite proper order.

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 3200, 320f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 3300, 200f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 3400, 260f);
		system.addAsteroidBelt(star, 150, 3300, 600, 300, 250, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 4000, 320f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4100, 240f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4200, 320f);
		system.addAsteroidBelt(star, 150, 4100, 300, 600, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 3, Color.white, 256f, 4300, 280f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4400, 180f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4500, 220f);
		system.addAsteroidBelt(star, 150, 4400, 600, 300, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 4500, 400f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4600, 280f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4700, 320f);
		//system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4800, 360f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4900, 360f);
		system.addAsteroidBelt(star, 200, 4700, 600, 300, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");


		//SectorEntityToken pirateStation = system.addOrbitalStation("kantas_den", star, 240, 4250, 160, "Kanta's Den", "pirates");
		SectorEntityToken pirateStation = system.addCustomEntity("kantas_den", "Kanta's Den", "station_side06", "pirates");
		pirateStation.setCustomDescriptionId("station_kantas_den");
		pirateStation.setInteractionImage("illustrations", "pirate_station");
		pirateStation.setCircularOrbitWithSpin(star, 220, 4250, 160, 6, 10);

		// Guayota Relay - L5 (behind); well, okay, not quite the L5. But whatever.
		SectorEntityToken guayota_relay = system.addCustomEntity("guayota_relay", // unique id
				"Guayota Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"neutral"); // faction

		guayota_relay.setCircularOrbitPointingDown( star, 150, 5900, 240);

		//SectorEntityToken civilianStation = system.addOrbitalStation("new_maxios", star, 0, 3900, 160, "New Maxios", "independent");
		SectorEntityToken civilianStation = system.addCustomEntity("new_maxios", "Nova Maxios", "station_side07", "independent");
		civilianStation.setCustomDescriptionId("station_new_maxios");
		civilianStation.setInteractionImage("illustrations", "cargo_loading");
		civilianStation.setCircularOrbitWithSpin(star, 45-45, 7900, 460, 4, 10);

		SectorEntityToken base_home_asteroid = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						500f, // min radius
						600f, // max radius
						40, // min asteroid count
						60, // max asteroid count
						6f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		base_home_asteroid.setCircularOrbit(star, 45-45, 7900, 460);

		// Magec Gate - counter-orbit to Achaman
		SectorEntityToken gate = system.addCustomEntity("magec_gate", // unique id
				"Magec Gate", // name - if null, defaultName from custom_entities.json will be used
				Entities.INACTIVE_GATE, // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(star, 45+45, 7900, 460);

		DebrisFieldParams params = new DebrisFieldParams(
				500f, // field radius - should not go above 1000 for performance reasons
				-1f, // density, visual - affects number of debris pieces
				10000000f, // duration in days
				0f); // days the field will keep generating glowing pieces
		params.source = DebrisFieldSource.MIXED;
		params.baseSalvageXP = 250; // base XP for scavenging in field
		SectorEntityToken debrisNextToGate = Misc.addDebrisField(system, params, StarSystemGenerator.random);
		debrisNextToGate.setSensorProfile(null);
		debrisNextToGate.setDiscoverable(null);
		debrisNextToGate.setCircularOrbit(gate, 0f, 0f, 100f);
		debrisNextToGate.setId("magec_debrisNextToGate");

		PlanetAPI magec2 = system.addPlanet("maxios", star, "Maxios", "desert1", 45, 140, 7900, 460);
		Misc.initConditionMarket(magec2);
		magec2.getMarket().addCondition(Conditions.DECIVILIZED);
		magec2.getMarket().addCondition(Conditions.RUINS_VAST);
		magec2.getMarket().getFirstCondition(Conditions.RUINS_VAST).setSurveyed(true);
		magec2.getMarket().addCondition(Conditions.METEOR_IMPACTS);
		magec2.getMarket().addCondition(Conditions.ORE_MODERATE);
		magec2.getMarket().addCondition(Conditions.RARE_ORE_RICH);
		magec2.getMarket().addCondition(Conditions.ORGANICS_COMMON);

		magec2.setCustomDescriptionId("planet_maxios");
		magec2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		magec2.getSpec().setGlowColor(new Color(255,245,235,255));
		magec2.getSpec().setUseReverseLightForGlow(true);
		magec2.getSpec().setAtmosphereThicknessMin(25);
		magec2.getSpec().setAtmosphereThickness(0.2f);
		magec2.getSpec().setAtmosphereColor( new Color(80,90,100,120) );
		magec2.applySpecChanges();

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("maxios_jump_point", "Maxios Jump-point");
		OrbitAPI orbit = Global.getFactory().createCircularOrbit(star, 800, 13200, 640);
		jumpPoint.setOrbit(orbit);
		jumpPoint.setRelatedPlanet(magec2);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		
		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
		//		1, 2, // min/max entities to add
		//		15000, // radius to start adding at
		//		4, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);

		system.autogenerateHyperspaceJumpPoints(true, true);
	}


}
