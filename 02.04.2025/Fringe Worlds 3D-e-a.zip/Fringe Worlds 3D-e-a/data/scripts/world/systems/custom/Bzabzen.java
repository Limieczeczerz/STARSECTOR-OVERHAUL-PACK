package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Bzabzen {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Bzabzen");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("bzabzen", // unique id for this star
				StarTypes.ORANGE, // id in planets.json
				1100f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				5f, // solar wind burn level
				2f, // flare probability
				2f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(202, 135, 150)); // light color in entire system, affects all entities

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 4, // min/max entities to add
				2000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		PlanetAPI bourbon = system.addPlanet("bourbon", star, "Bourbon", "terran", 350, 140, 10000, 455);
		bourbon.setCustomDescriptionId("planet_bourbon");
		
		PlanetAPI boboon = system.addPlanet("boboon", bourbon, "Boboon", "barren2", 40, 50, 500, 20);
		boboon.setCustomDescriptionId("planet_boboon");
		SectorEntityToken morbius_station = system.addCustomEntity("morbius_station", "Morbius Station", "station_side05", "independent");
		morbius_station.setCircularOrbitPointingDown(system.getEntityById("boboon"), 0, 100, 10);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Voronira Entry-point");
		jumpPoint.setCircularOrbit( system.getEntityById("bzabzen"), 50+40, 14400, 690);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		//jumpPoint.setRelatedPlanet(bourbon);
		system.addEntity(jumpPoint);
		SectorEntityToken field = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						750f, // min radius
						1000f, // max radius
						20, // min asteroid count
						25, // max asteroid count
						6f, // min asteroid radius
						10f, // max asteroid radius
						"Marceline")); // null for default name
		field.setCircularOrbit(star, 50+40, 14400, 690);
			
		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "comm_relay", Factions.PERSEAN);
		don_eladio.setCircularOrbitPointingDown(star, 50-40, 14400, 690);

		SectorEntityToken nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
						"xxxxxx" +
						"  xxxx" +
						"xx    " +
						" x x  " +
						"   xx " +
						"  x   ",
				6, 6, // size of the nebula grid, should match above string
				"terrain", "nebula", 4, 4, "Bonnibel"));
		nebula.setId("nebula");
		nebula.setCircularOrbit(star, 50-40, 14400, 690);

		PlanetAPI gigamad = system.addPlanet("gigamad", star, "Gigamad", "gas_giant", 50, 440, 14400, 690);
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,225,255,255), 256f, 1000, 200f, Terrain.RING, "Anger of Asmongold");
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,240,240,255), 256f, 1200, 200f, Terrain.RING, "Anger of Asmongold");

			SectorEntityToken onion_ring_station = system.addCustomEntity("onion_ring_station", "Derakh Sanctuarium", "station_side07", "luddic_church");
			onion_ring_station.setCircularOrbitPointingDown(system.getEntityById("gigamad"), -50, 1100, 50);
			onion_ring_station.setCustomDescriptionId("station_onion_ring");

			
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
