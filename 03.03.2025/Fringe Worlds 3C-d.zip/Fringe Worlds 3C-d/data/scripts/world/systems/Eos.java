package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

public class Eos {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Eos Exodus");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");
		
		SectorEntityToken eos_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/eos_nebula.png",
				  0, 0, // center of nebula
				  system, // location to add to
				  "terrain", "nebula_blue", // "nebula_blue", // texture to use, uses xxx_map for map
				  4, 4, StarAge.YOUNG); // number of cells in texture
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("eos",
										"star_red_giant", // id in planets.json
										1550f, 		// radius (in pixels at default zoom)
										1000, // corona radius, from star edge
										5f, // solar wind burn level
										1f, // flare probability
										2f); // cr loss mult
		system.setLightColor(new Color(201, 110, 56)); // light color in entire system, affects all entities

		JumpPointAPI eos2JumpPoint_extra = Global.getFactory().createJumpPoint("paladins_bridge", "Tatar Exit");
		eos2JumpPoint_extra.setCircularOrbit(system.getEntityById("eos"), 0, 4000, 150);
		eos2JumpPoint_extra.setStandardWormholeToHyperspaceVisual();
		system.addEntity(eos2JumpPoint_extra);
		
		PlanetAPI eos1 = system.addPlanet("phaosphoros", star, "Phaosphoros", "gas_giant", 240, 410, 6200, 320);
		eos1.getSpec().setAtmosphereColor(new Color(255,245,200,220));
		eos1.getSpec().setPlanetColor(new Color(245,250,255,255));
		eos1.applySpecChanges();
		eos1.setCustomDescriptionId("hot_gas_giant");
		eos1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		eos1.getSpec().setGlowColor(new Color(245,50,20,100));
		eos1.getSpec().setUseReverseLightForGlow(true);
		eos1.getSpec().setAtmosphereThickness(0.5f);
		eos1.getSpec().setCloudRotation( 10f );
		eos1.getSpec().setPitch(20);
		eos1.getSpec().setAtmosphereThicknessMin(80);
		eos1.getSpec().setAtmosphereThickness(0.30f);
		eos1.getSpec().setAtmosphereColor(new Color(255,150,50,205));

		PlanetAPI eos1a = system.addPlanet("lucifer", eos1, "Lucifer", "rocky_unstable", 0, 60, 650, 36);

		// Asteroids - "The Pilgrims"
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 8980, 205f, null, null);
		system.addAsteroidBelt(star, 150, 8980, 250, 150, 250, Terrain.ASTEROID_BELT, "The Pilgrims");
		PlanetAPI eos3b = system.addPlanet("daedaleon", star, "Daedaleon", "water", -200, 80, 8580, 380);
		eos3b.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		eos3b.getSpec().setGlowColor(new Color(255,55,250,200));
		eos3b.getSpec().setUseReverseLightForGlow(true);
		eos3b.applySpecChanges();
		eos3b.setCustomDescriptionId("planet_daedaleon");

		// needs a warning beacon!
		CustomCampaignEntityAPI beacon = system.addCustomEntity(null, null, Entities.WARNING_BEACON, Factions.NEUTRAL);
		beacon.setCircularOrbitPointingDown(eos3b, 0, 250, 10);
		beacon.getMemoryWithoutUpdate().set("$daedaleon", true);
			
			// Phaosphoros trojans
			SectorEntityToken phaosphorosL4 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						300f, // min radius
						500f, // max radius
						10, // min asteroid count
						15, // max asteroid count
						4f, // min asteroid radius 
						12f, // max asteroid radius
						"Cherubim Asteroids")); // null for default name
			
			SectorEntityToken phaosphorosL5 = system.addTerrain(Terrain.ASTEROID_FIELD,
					new AsteroidFieldParams(
						300f, // min radius
						500f, // max radius
						10, // min asteroid count
						15, // max asteroid count
						4f, // min asteroid radius 
						12f, // max asteroid radius
						"Seraphim Asteroids")); // null for default name
			
			phaosphorosL4.setCircularOrbit(star, 240 + 60, 10300, 510);
			phaosphorosL5.setCircularOrbit(star, 240 - 60, 10800, 600);

			PlanetAPI eos2a = system.addPlanet("baetis", star, "Baetis", "barren_castiron", 240 - 60, 60, 10300, 600);
			eos2a.setCustomDescriptionId("planet_baetis");
			eos2a.getSpec().setAtmosphereThicknessMin(20);
			eos2a.getSpec().setAtmosphereThickness(0.06f);
			eos2a.getSpec().setAtmosphereColor( new Color(250, 220, 120, 128) );
			eos2a.applySpecChanges();

			PlanetAPI eos2 = system.addPlanet("tartessus", star, "Tartessus", "arid", 0, 170, 12400, 600);
			//eos2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
			//eos2.getSpec().setGlowColor(new Color(245,255,250,255));
			//eos2.getSpec().setUseReverseLightForGlow(true);
			//eos2.applySpecChanges();
			eos2.setCustomDescriptionId("planet_tartessus");
		
			system.addRingBand(eos2, "misc", "rings_special0", 256f, 1, new Color(225,215,255,255), 128f, 480, 30f, Terrain.RING, "The Grace of Tartessus");
			// 256f
		
			// Tartessus Jumppoint - Tartessus L5 (behind)
			JumpPointAPI eos2JumpPoint = Global.getFactory().createJumpPoint("paladins_bridge", "Paladins' Bridge");
			eos2JumpPoint.setCircularOrbit(system.getEntityById("eos"), 200-60, 12000, 420);
			eos2JumpPoint.setRelatedPlanet(eos2);
			
			eos2JumpPoint.setStandardWormholeToHyperspaceVisual();
			system.addEntity(eos2JumpPoint);
			
			// counter-orbit sensor array
			SectorEntityToken tartessus_sensor = system.addCustomEntity(null, null, "sensor_array_makeshift", "luddic_church");
			tartessus_sensor.setCircularOrbitPointingDown( star, 200 - 180, 4400, 120);
			
			
		SectorEntityToken relay = system.addCustomEntity("hesperus_relay", "Hesperus Relay", "comm_relay", "luddic_church");
		relay.setCircularOrbitPointingDown( star, 0 + 60, 7400, 200);
		
		// Eos Exodus Gate - Tartessus L4 (ahead)
		SectorEntityToken gate = system.addCustomEntity("eos_exodus_gate", // unique id
				 "Eos Exodus Gate", // name - if null, defaultName from custom_entities.json will be used
				 "inactive_gate", // type of object, defined in custom_entities.json
				 null); // faction
		
		gate.setCircularOrbit(system.getEntityById("eos"), 150+60, 12800, 450);

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
		//		1, 2, // min/max entities to add
		//		14600, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds

		PlanetAPI astrae = system.addPlanet("astrae", star, "Astrae", "ice_giant", -200, 380, 15600, 800);
		astrae.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		astrae.getSpec().setGlowColor(new Color(165,229,250,155));
		astrae.applySpecChanges();

		PlanetAPI eos3 = system.addPlanet("hesperus", star, "Hesperus", "frozen", 200, 180, 17400, 1240);
			//eos3.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
			//eos3.getSpec().setGlowColor(new Color(197,34,245,255));
			//eos3.getSpec().setUseReverseLightForGlow(true);
			//eos3.applySpecChanges();
			eos3.setCustomDescriptionId("planet_hesperus");
			eos3.setInteractionImage("illustrations", "hesperus");

			PlanetAPI eos3a = system.addPlanet("ceyx", eos3, "Ceyx", "barren_venuslike", 0, 50, 460, 16);
			eos3a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "barren"));
			eos3a.getSpec().setGlowColor(new Color(200,230,255,200));
			eos3a.getSpec().setUseReverseLightForGlow(true);
			eos3a.applySpecChanges();
			eos3a.setCustomDescriptionId("planet_ceyx");
			eos3a.setFaction(Factions.KOL);

		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(false, false);
	}
	
	
}
