package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Vobo {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Vobo");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");

		PlanetAPI star = system.initStar("vobo", "star_purple_giant", 1620, 2000, 20f, 2f, 8f);

		system.setLightColor(new Color(236, 191, 255)); // light color in entire system, affects all entities

		SectorEntityToken overlord_broadcast = system.addCustomEntity("overlord_broadcast", // unique id
				"Overlord Broadcast Station", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		overlord_broadcast.setCircularOrbitPointingDown(star, -60, 6600, 200);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				2, 4, // min/max entities to add
				8000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		JumpPointAPI jumppoint_oro = Global.getFactory().createJumpPoint("jumppoint_oro", "Jump-Point Oro");
		jumppoint_oro.setCircularOrbit(system.getEntityById("Vobo"), 100, 4200, 150);

		jumppoint_oro.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumppoint_oro);

		PlanetAPI living_nightmare = system.addPlanet("living_nightmare", star, "Living Nightmare", "fire_giant", 120, 410, 16250, 720);
		living_nightmare.getSpec().setAtmosphereColor(new Color(255,245,200,220));
		living_nightmare.getSpec().setPlanetColor(new Color(245,250,255,255));
		living_nightmare.applySpecChanges();
		living_nightmare.getSpec().setAtmosphereThickness(0.5f);
		living_nightmare.getSpec().setCloudRotation( 10f );
		living_nightmare.getSpec().setAtmosphereThicknessMin(80);
		living_nightmare.getSpec().setAtmosphereThickness(0.30f);
		living_nightmare.getSpec().setAtmosphereColor(new Color(255,150,50,205));

			system.addRingBand(living_nightmare, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 800, 30f, Terrain.RING, "Passage of Neo");

			PlanetAPI broken_bone = system.addPlanet("broken_bone", living_nightmare, "Broken Bone", "barren2", 10, 100, 1250, 60);
			broken_bone.setCustomDescriptionId("planet_broken_bone");
			
				SectorEntityToken broken_bone_station = system.addCustomEntity("abandoned_station", "Operation Zero", "station_mining00", "tritachyon");
				broken_bone_station.setCircularOrbitPointingDown(system.getEntityById("broken_bone"), -10, 200, 10);
				broken_bone_station.setCustomDescriptionId("station_broken_bone");
				broken_bone_station.setInteractionImage("illustrations", "orbital_construction");

		PlanetAPI rippers_morld = system.addPlanet("rippers_morld", star, "Ripper's Morld", "water", -0, 140, 18880, 800);
		rippers_morld.setCustomDescriptionId("planet_rippers_morld");
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(100f, // terrain effect band width
						200, // terrain effect middle radius
						rippers_morld, // entity that it's around
						150f, // visual band start
						250f, // visual band end
						new Color(25, 77, 145, 40), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(25, 77, 145, 130),
						new Color(25, 92, 179, 150),
						new Color(36, 112, 212, 190),
						new Color(42, 130, 245, 140),
						new Color(43, 68, 255, 155),
						new Color(43, 255, 239),
						new Color(43, 201, 255)
				));
		field.setCircularOrbit(rippers_morld, 0, 0, 30);

		SectorEntityToken shade_0 = system.addCustomEntity("eventide_mirror1", "Shield Alpha-Omega_0", "stellar_shade", "tritachyon");
		shade_0.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180, 400, 600);
		shade_0.setCustomDescriptionId("stellar_shade");
		SectorEntityToken shade_1 = system.addCustomEntity("eventide_mirror2", "Shield Alpha-Omega_1", "stellar_shade", "tritachyon");
		shade_1.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180+30, 400, 600);
		shade_1.setCustomDescriptionId("stellar_shade");
		SectorEntityToken shade_2 = system.addCustomEntity("eventide_mirror3", "Shield Alpha-Omega_2", "stellar_shade", "tritachyon");
		shade_2.setCircularOrbitPointingDown(system.getEntityById("rippers_morld"), -180-30, 400, 600);
		shade_2.setCustomDescriptionId("stellar_shade");

		PlanetAPI old_bob = system.addPlanet("old_bob", star, "Old Bob", "barren-bombarded", -440, 150, 18000, 840);
		old_bob.setCustomDescriptionId("planet_old_bob");
		Misc.initConditionMarket(old_bob);;
		old_bob.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		old_bob.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);
		old_bob.getMarket().addCondition(Conditions.RARE_ORE_ABUNDANT);
		old_bob.getMarket().addCondition(Conditions.ORE_ABUNDANT);
		old_bob.getMarket().addCondition(Conditions.NO_ATMOSPHERE);

		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
