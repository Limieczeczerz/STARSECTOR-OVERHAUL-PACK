package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Oppenheimer {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Oppenheimer");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("oppenheimer", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				575f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(181, 29, 179)); // light color in entire system, affects all entities

		//system is too crowded, removing these. Brown giant shouldn't have that much shit going on

		PlanetAPI jerma = system.addPlanet("jerma", star, "Jerma", "gas_giant", 90, 430, 3500, 120);
		system.addRingBand(jerma, "misc", "rings_dust0", 256f, 1, new Color(200,255,255,255), 256f, 1200, 50f, Terrain.RING, null);
		jerma.setCustomDescriptionId("planet_jerma");
		SectorEntityToken star_station = system.addCustomEntity("star_station", "Star's Station", "station_side05", "hegemony");
		star_station.setCircularOrbitPointingDown(system.getEntityById("jerma"), 0, 500, 20);

		PlanetAPI false_prophet = system.addPlanet("false_prophet", jerma, "False Prophet", "lava_minor", 22, 60, 800, 50);
		false_prophet.setCustomDescriptionId("planet_false_prophet");

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Dominator Jump-point");
		jumpPoint.setCircularOrbit(system.getEntityById("oppenheimer"), 150, 4800, 250);
		system.addEntity(jumpPoint);
		jumpPoint.setStandardWormholeToHyperspaceVisual();

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				"Jameson Vorhee", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		relay.setCircularOrbitPointingDown(star, 100, 1500, 200);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 4, // min/max entities to add
				5600, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
